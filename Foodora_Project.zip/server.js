const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 8080;
const KEY = process.env.ADMIN_KEY || "Foodora@Admin#2026";
const DB = path.join(__dirname,"orders.json");
const PRODUCTS = path.join(__dirname,"products.json");

app.use(express.json({limit:"1mb"}));
app.use(express.static(__dirname));

const initial = [
["Classic Beef Burger","Burger",250,"🍔","Juicy beef, fresh lettuce and signature sauce."],
["Italian Cheese Pizza","Pizza",450,"🍕","Loaded with mozzarella and fresh toppings."],
["Crispy Fried Chicken","Chicken",220,"🍗","Golden crispy chicken."],
["Chocolate Cake","Dessert",180,"🍰","Rich chocolate and creamy delight."],
["Fresh Fruit Drink","Drinks",130,"🥤","Refreshing fruit drink."],
["Grilled Chicken Meal","Chicken",320,"🍗","Tender grilled chicken."],
["Chicken Burger","Burger",200,"🍔","Crispy chicken with creamy sauce."],
["Pepperoni Pizza","Pizza",520,"🍕","Classic pepperoni and cheese."],
["French Fries","Snacks",100,"🍟","Golden crispy fries."],
["Chicken Sandwich","Snacks",180,"🥪","Fresh and delicious sandwich."],
["Chocolate Donut","Dessert",90,"🍩","Soft chocolate donut."],
["Strawberry Shake","Drinks",160,"🥤","Fresh strawberry milkshake."],
["Chicken Wings","Chicken",260,"🍗","Spicy crispy wings."],
["Pasta Alfredo","Pasta",280,"🍝","Creamy Alfredo pasta."],
["Vanilla Ice Cream","Dessert",120,"🍨","Smooth vanilla ice cream."],
["Hot Coffee","Drinks",100,"☕","Freshly brewed coffee."],
["BBQ Pizza","Pizza",480,"🍕","Smoky BBQ chicken pizza."],
["Chicken Nuggets","Snacks",150,"🍗","Crispy golden nuggets."],
["Beef Pasta","Pasta",350,"🍝","Rich beef pasta."],
["Special Burger","Burger",300,"🍔","Our signature special burger."]
];

function read(file, fallback) {
 try { return JSON.parse(fs.readFileSync(file,"utf8")); }
 catch { fs.writeFileSync(file,JSON.stringify(fallback,null,2)); return fallback; }
}
function write(file,data) {
 fs.writeFileSync(file,JSON.stringify(data,null,2));
}
read(DB,[]);
read(PRODUCTS,initial);

function auth(req,res,next) {
 if(req.headers["x-admin-key"] !== KEY)
 return res.status(401).json({error:"Incorrect admin password"});
 next();
}

app.get("/api/products",(req,res)=>res.json(read(PRODUCTS,initial)));

app.post("/api/orders",(req,res)=>{
 const {name,phone,address,payment,items}=req.body;
 if(typeof name!=="string" || name.trim().length<2 ||
 !/^01[0-9]{9}$/.test(phone||"") ||
 typeof address!=="string" || address.trim().length<5 ||
 !Array.isArray(items) || !items.length || items.length>30)
 return res.status(400).json({error:"Please enter valid customer details."});

 const products=read(PRODUCTS,initial);
 let clean=[],subtotal=0;
 for(const item of items){
  const p=products.find(x=>String(x.id)===String(item.id));
  const qty=Number(item.qty);
  if(!p || !Number.isInteger(qty) || qty<1 || qty>50)
   return res.status(400).json({error:"Invalid product or quantity."});
  clean.push({id:p.id,name:p.name,price:p.price,qty});
  subtotal+=p.price*qty;
 }
 const delivery=subtotal>=999?0:60;
 const order={
  id:Date.now().toString(),name:name.trim(),phone,
  address:address.trim(),
  payment:["Cash on Delivery","bKash","Nagad"].includes(payment)?payment:"Cash on Delivery",
  items:clean,subtotal,delivery,total:subtotal+delivery,
  status:"Pending",createdAt:new Date().toISOString()
 };
 const orders=read(DB,[]);
 orders.unshift(order);
 write(DB,orders);
 res.json({success:true,orderId:order.id,total:order.total});
});

app.get("/api/admin/orders",auth,(req,res)=>res.json(read(DB,[])));

app.patch("/api/admin/orders/:id",auth,(req,res)=>{
 const allowed=["Pending","Confirmed","Preparing","Delivered","Cancelled"];
 if(!allowed.includes(req.body.status))
 return res.status(400).json({error:"Invalid status"});
 const orders=read(DB,[]);
 const o=orders.find(x=>x.id===req.params.id);
 if(!o)return res.status(404).json({error:"Not found"});
 o.status=req.body.status;
 write(DB,orders);
 res.json({success:true});
});

app.post("/api/admin/products",auth,(req,res)=>{
 const {name,category,price,emoji,description}=req.body;
 if(typeof name!=="string" || !name.trim() ||
 typeof category!=="string" || !Number.isFinite(Number(price)) ||
 Number(price)<1 || Number(price)>100000)
 return res.status(400).json({error:"Invalid product"});
 const products=read(PRODUCTS,initial);
 const p={id:Date.now().toString(),name:name.trim(),
 category:category.trim(),price:Number(price),
 emoji:String(emoji||"🍽️").slice(0,8),
 description:String(description||"Fresh and delicious").slice(0,200)};
 products.push(p);
 write(PRODUCTS,products);
 res.json({success:true,product:p});
});

app.delete("/api/admin/products/:id",auth,(req,res)=>{
 const products=read(PRODUCTS,initial);
 const updated=products.filter(p=>String(p.id)!==req.params.id);
 if(updated.length===products.length)return res.status(404).json({error:"Not found"});
 write(PRODUCTS,updated);
 res.json({success:true});
});

app.get("/api/health",(req,res)=>res.json({status:"online"}));

app.listen(PORT,"0.0.0.0",()=>{
 console.log("FOODORA V3 IS ONLINE");
 console.log("Website: http://127.0.0.1:"+PORT);
 console.log("Admin: http://127.0.0.1:"+PORT+"/admin.html");
 console.log("Admin password: set using ADMIN_KEY environment variable");
});
